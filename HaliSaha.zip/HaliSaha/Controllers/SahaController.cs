using HaliSaha.Areas.Identity.Data;
using HaliSaha.Models;
using Microsoft.AspNetCore.Mvc;
//using HaliSaha.Data;

using Microsoft.EntityFrameworkCore;





namespace HaliSaha.Controllers
{
    public class SahaController : Controller
    {


        private readonly IHttpClientFactory _factory;  //api den ileti�imi a�layacak
        private readonly HaliSahaContext _context;

        public SahaController(HaliSahaContext context, IHttpClientFactory factory)
        {
            _context = context;
            _factory = factory;
        }

        public async Task<IActionResult> Index()
        {
            try
            {
                //haberle�me i�in client'� newliyoruz.
                var client = _factory.CreateClient();

                //API'deki adresi yaz�yoruz
                client.BaseAddress = new Uri("http://localhost:5070/api/SahaAPI");

                //bu adres kullan�larak API'den hepsini �ekiyoruz.
                var sahalar = await client.GetFromJsonAsync<List<Saha>>(client.BaseAddress);

                //API'den gelenleri view'�na g�nderiyoruz.
                return View(sahalar ?? new List<Saha>());
            }
            catch (Exception ex)
            {
                ViewBag.Error = $"Sahalar y�klenirken hata olu�tu: {ex.Message}";
                return View(new List<Saha>());
            }
        }

        public IActionResult Ekle()
        {
            return View();
        }

        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> Ekle(Saha saha)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        _context.Sahalar.Add(saha);
        //        await _context.SaveChangesAsync();
        //        return RedirectToAction(nameof(Index));
        //    }
        //    return View(saha);
        //}

        //yeni 03.12.2025
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Ekle(Saha saha)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    //haberle�me i�in client'� newliyoruz.
                    var client = _factory.CreateClient();

                    //API'deki adresi yaz�yoruz
                    client.BaseAddress = new Uri("http://localhost:5070/api/SahaAPI");

                    //bu adres kullan�larak API'yi �a��r�yoruz.
                    var response = await client.PostAsJsonAsync(client.BaseAddress, saha);

                    if (response.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        var content = await response.Content.ReadAsStringAsync();
                        ModelState.AddModelError("", $"API Hatas�: {content}");
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", $"Bir hata olu�tu: {ex.Message}");
                }
            }
            return View(saha);
        }



        // D�zenleme
        public async Task<IActionResult> Duzenle(int id)
        {
            try
            {
                //haberle�me i�in client'� newliyoruz.
                var client = _factory.CreateClient();

                //API'deki adresi yaz�yoruz
                client.BaseAddress = new Uri("http://localhost:5070/api/SahaAPI/" + id);

                //bu adres kullan�larak API'den hepsini �ekiyoruz.
                var saha = await client.GetFromJsonAsync<Saha>(client.BaseAddress);

                if (saha == null) return NotFound();
                return View(saha);
            }
            catch (Exception ex)
            {
                ViewBag.Error = $"Saha y�klenirken hata olu�tu: {ex.Message}";
                return NotFound();
            }
        }





        [HttpPost]
        public async Task<IActionResult> Duzenle(Saha saha)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    //haberle�me i�in client'� newliyoruz.
                    var client = _factory.CreateClient();

                    //API'deki adresi yaz�yoruz
                    client.BaseAddress = new Uri("http://localhost:5070/api/SahaAPI/" + saha.Id);

                    //bu adres kullan�larak API'yi �a��r�yoruz.
                    var response = await client.PutAsJsonAsync<Saha>(client.BaseAddress, saha);

                    if (response.IsSuccessStatusCode)
                    {
                        return RedirectToAction(nameof(Index));
                    }
                    else
                    {
                        var content = await response.Content.ReadAsStringAsync();
                        ModelState.AddModelError("", $"API Hatas�: {content}");
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", $"Bir hata olu�tu: {ex.Message}");
                }
            }
            return View(saha);
        }
        // Silme
        [HttpPost]
        public async Task<IActionResult> Sil(int id)
        {
            try
            {
                //haberle�me i�in client'� newliyoruz.
                var client = _factory.CreateClient();

                //API'deki adresi yaz�yoruz
                client.BaseAddress = new Uri("http://localhost:5070/api/SahaAPI/" + id);

                //bu adres kullan�larak API'den hepsini �ekiyoruz.
                var saha = await client.GetFromJsonAsync<Saha>(client.BaseAddress);

                if (saha != null)
                {
                    var response = await client.DeleteAsync(client.BaseAddress);
                    if (!response.IsSuccessStatusCode)
                    {
                        TempData["Error"] = "Saha silinirken hata olu�tu";
                    }
                }
                else
                {
                    TempData["Error"] = "Saha bulunamad�";
                }
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Hata: {ex.Message}";
            }
            return RedirectToAction(nameof(Index));
        }









        }
}
