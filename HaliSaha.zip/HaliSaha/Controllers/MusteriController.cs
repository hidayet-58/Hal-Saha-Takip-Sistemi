
using HaliSaha.Areas.Identity.Data;
using HaliSaha.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace HaliSaha.Controllers
{
   
    public class MusteriController : Controller  //controlleri miras al�r. miras almak http isteklerini get,post yakalay�p yan�t vermeyi sa�lar.
    {
        
        private readonly IHttpClientFactory _factory;  //api den ileti�imi a�layacak, ba��ml�l�klar

        private readonly HaliSahaContext _context;   //veritaban�na ba�lanmak i�in entity framework kullan�yoruz.

      //ba�l�l�klar inject edildi.
        public MusteriController(HaliSahaContext context, IHttpClientFactory factory)
        {
            //bunlarala veritaban� ve api ye eri�im i�in....
            _context = context;
            _factory=factory;
        }

        // Listeleme
        public async Task<IActionResult> Index()
        {
            try  //hata y�netimini yapmak i�in....
            {
                //haberle�me i�in client'� newliyoruz. bu nesne ile aPI istekleri yap�l�yor...
                var client = _factory.CreateClient();

                //API'deki adresi yaz�yoruz, temel adres belirlemek i�in.....
                client.BaseAddress = new Uri("http://localhost:5070/api/MusteriApi");
                //await metodu asenkron oldu�unu g�sterir UI yi bloklamaz.


                //bu adres kullan�larak API'den hepsini �ekiyoruz.
                var musteriler = await client.GetFromJsonAsync<List<Musteri>>(client.BaseAddress);

                //API'den gelenleri view'�na g�nderiyoruz.
                return View(musteriler ?? new List<Musteri>());
            }
            //hata durumund mesaj g�ndermek i�in 
            catch (Exception ex)
            {
                ViewBag.Error = $"M��teriler y�klenirken hata olu�tu: {ex.Message}";
                return View(new List<Musteri>()); //view her durumda cal���r bo� liste d�ner...
            }
        }

        // Ekleme
        public IActionResult Ekle() //kullan�c� yeni m��teri ekelemk istei�inde bo� form cal���r....
        {
            return View();
        }

        [HttpPost]   //formdan gelen veriyi API ye g�ndermek i�in...
        public async Task<IActionResult> Ekle(Musteri musteri)  //Musteri modeli view den g�nderilir....
        {

            //model do�rulama.
            if (ModelState.IsValid)
            {
                try
                {
                    //haberle�me i�in client'� newliyoruz.
                    var client = _factory.CreateClient();

                    //API'deki adresi yaz�yoruz
                    client.BaseAddress = new Uri("http://localhost:5070/api/MusteriApi");

                    var response = await client.PostAsJsonAsync(client.BaseAddress, musteri); //JSON a d�n��t�r�p api ye g�deirir.

                    if (response.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index"); //api den ba�ar�l�o yan�t gelirse listeleme sayfas�na gifder.
                    }
                    else
                    {
                        var content = await response.Content.ReadAsStringAsync();
                        ModelState.AddModelError("", $"API Hatas�: {content}"); //api den hata mesaj� gelirse modelstate e ekler.
                    }
                }
                catch (Exception ex) //gelen hatalarda kullan�c�ya mesaj g�stermek i�in...
                {
                    ModelState.AddModelError("", $"Bir hata olu�tu: {ex.Message}");
                }
            }
            return View(musteri);
        }

        // D�zenleme
        public async Task<IActionResult> Duzenle(int id) //d�zenlenecek m��terinin id veritaban�ndaki kimli�idir.
        {
            try
            {
                //haberle�me i�in client'� newliyoruz.
                var client = _factory.CreateClient();

                //API'deki adresi yaz�yoruz
                client.BaseAddress = new Uri("http://localhost:5070/api/MusteriApi/" + id);

                //bu adres kullan�larak API'den m��teri hep verisini hepsini �ekiyoruz.
                var musteri = await client.GetFromJsonAsync<Musteri>(client.BaseAddress);

                if (musteri == null) return NotFound();//veriyi kontrol eder bulunmazsa musteri 404 d�ner.
                return View(musteri);  //veri bulunursa view a g�nderir.
            }
            catch (Exception ex) //hata durumunda mesaj g�stermek i�in...
            {
                ViewBag.Error = $"M��teri y�klenirken hata olu�tu: {ex.Message}";
                return NotFound();
            }
        }

        [HttpPost]
        public async Task<IActionResult> Duzenle(Musteri musteri) //musteri model view den g�nderilir.
        {
            if (ModelState.IsValid)  //model do�rulamaa
            {
                try
                {
                    //haberle�me i�in client'� newliyoruz.
                    var client = _factory.CreateClient();

                    //API'deki adresi yaz�yoruz
                    client.BaseAddress = new Uri("http://localhost:5070/api/MusteriApi/" + musteri.Id); //api url si g�ncellenecek musteri id si ile ayarland�.

                    //musteri nesnesini json formtinde apiye g�nderir ve g�nceller..
                    var response = await client.PutAsJsonAsync<Musteri>(client.BaseAddress, musteri);

                    if (response.IsSuccessStatusCode)
                    {
                        return RedirectToAction(nameof(Index)); //api basar�l� ise m��teri nesnesine y�nlendirilir.
                    }
                    else
                    {
                        var content = await response.Content.ReadAsStringAsync();
                        ModelState.AddModelError("", $"API Hatas�: {content}");
                    }
                }
                catch (Exception ex)
                {//kullan�c�ya hata mesaj� g�nder.
                    ModelState.AddModelError("", $"Bir hata olu�tu: {ex.Message}");
                }
            }
            return View(musteri);
        }

        // Silme
        [HttpPost]
        public async Task<IActionResult> Sil(int id) //silinewcek m��terini kimli�i id..
        {
            try
            {
                //haberle�me i�in client'� newliyoruz.
                var client = _factory.CreateClient();

                //API'deki adresi yaz�yoruz
                client.BaseAddress = new Uri("http://localhost:5070/api/MusteriApi/" + id); //silinecek musterini idsine �zel url belirlenir.

                //bu adres kullan�larak API'den hepsini �ekiyoruz. musteri varm�...
                var musteri = await client.GetFromJsonAsync<Musteri>(client.BaseAddress);

                if (musteri != null)
                {//apiye delete iste�i g�ndermek i�in...
                    var response = await client.DeleteAsync(client.BaseAddress); //m��teri varsa api ye delete iste�i g�nderir..
                    if (!response.IsSuccessStatusCode)
                    {
                        TempData["Error"] = "M��teri silinirken hata olu�tu";
                    }
                }
                else
                {
                    TempData["Error"] = "M��teri bulunamad�";
                }
            }
            catch (Exception ex) //hata durumunda mesaj g�stermek i�in...
            {
                TempData["Error"] = $"Hata: {ex.Message}";
            }
            return RedirectToAction(nameof(Index)); //silme i�lemi ba�ar�l� veay ba�ar�s�z olsun listeleme sayfas�na y�nlendir.
        }
    }
}

