
using HaliSaha.Areas.Identity.Data;
using HaliSaha.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;







namespace HaliSaha.Controllers
{


    public class RezervasyonController : Controller
    {

        private readonly IHttpClientFactory _factory; //http istekleri api ca�r�lar� get,post.....
        private readonly HaliSahaContext _context; //veritaban�na eri�mek i�in kullan�l�r,tablolar sorgular...
        private readonly UserManager<HaliSahaUser> _usermanager; //kullan�c� y�netimi i�in identity kullan�c�lar�yla ilgili i�lemler silme , g�ncelleme vs...


        //parametreler , asp.ner core taraf�ndan otomatik sa�lan�r...controller i�indeki t�m action metotlar bu servisleri kullano�r.
        public RezervasyonController(IHttpClientFactory factory, UserManager<HaliSahaUser> usermanager)
        {

            _factory = factory; //http istekleri i�in kullam�l�r...
            _usermanager = usermanager; //asp.net identity kullan�c� y�netimi i�in kullan...
        }



        //apiden rezervasyon verilerini �ekip view e g�nderiri..
        public async Task<IActionResult> Index() //api ca�r�s� yap�ld��� i�in metot asyn tan�mlan�r.
        {
            try 
            {
                var client = _factory.CreateClient(); //Bu nesne ile API�ye GET, POST, PUT, DELETE istekleri yap�labilir.

                //API'deki adresi yaz�yoruz
                client.BaseAddress = new Uri("http://localhost:5070/api/RezervasyonAPI");        //bu adres kullan�larak API'den hepsini �ekiyoruz.
                var rezervasyonlar = await client.GetFromJsonAsync<List<Rezervasyon>>(client.BaseAddress); //apiden rezervasyon verileri cekilir....

                return View(rezervasyonlar ?? new List<Rezervasyon>()); //api bo� d�nerse bo� liste g�nder...
            }
            catch (Exception ex)
            {
                ViewBag.Error = $"Rezervasyonlar y�klenirken hata olu�tu: {ex.Message}";
                return View(new List<Rezervasyon>());
            }
        }





        //public async Task<IActionResult> Ekle()
        //{
        //    ViewBag.Musteriler = await _context.Musteriler.ToListAsync();
        //    ViewBag.Sahalar = await _context.Sahalar.ToListAsync();
        //    return View();
        //}

        //GET: Yeni rezervasyon formu
        public async Task<IActionResult> Ekle()
        {
            try
            {
                var client = _factory.CreateClient();

                client.BaseAddress = new Uri("http://localhost:5070/api/SahaAPI/");
                var sahalar = await client.GetFromJsonAsync<List<Saha>>(client.BaseAddress); //saha listesini apiden  ceker. dropdown liste oldarak kullano��o�r.

                var musteriler = await client.GetFromJsonAsync<List<Musteri>>("http://localhost:5070/api/MusteriApi"); //m��teri listesini apiden ceker. dropdown liste olarak kullan�l�r viewe g�nderiri...

                ViewBag.MusteriId = new SelectList(musteriler, "Id", "AdSoyad"); //musteri se�imi i�in dropdown liste olu�turur....
                ViewBag.SahaId = new SelectList(sahalar, "Id", "Ad");   //saha se�imi i�in dropdown liste olu�turur....
            }
            catch (Exception ex)
            {
                ViewBag.Error = $"Veriler y�klenirken hata: {ex.Message}";
            }
            return View(); //haz�rlananlar form view e g�nderilir...
        }





        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Ekle(Rezervasyon rezervasyon)
        {
            // Saat kontrol�
            if (rezervasyon.BitisSaati <= rezervasyon.BaslangicSaati)
            {
                ModelState.AddModelError("", "Biti� saati ba�lang�� saatinden sonra olmal�."); //hatal� ise d�ner..
            }

            var client = _factory.CreateClient(); //api ca�r�lar� i�in httpclient olu�turulur...

            if (ModelState.IsValid) //saat ve model do�rulama ba�ar�l� ise rez ekleme i�lemi yap�l�r...
            {
                try
                {
                    // Saha saatlik �creti al
                    client.BaseAddress = new Uri("http://localhost:5070/api/SahaAPI/" + rezervasyon.SahaId); //rez yap�lan saha apiden cekilir..
                    var saha1 = await client.GetFromJsonAsync<Saha>(client.BaseAddress); //saha listeini apiden ceker.....

                    if (saha1 == null)
                    {
                        ModelState.AddModelError("", "Se�ilen saha bulunamad�!");
                        throw new InvalidOperationException("Saha bulunamad�");
                    }

                    // S�re hesapla
                    var saat = (decimal)(rezervasyon.BitisSaati - rezervasyon.BaslangicSaati).TotalHours;
                    rezervasyon.ToplamUcret = saat * saha1.SaatlikUcret;

                    //rez  API'ye g�nder - navigation propertieleri bo� g�ndermiyoruz
                    var response = await client.PostAsJsonAsync("http://localhost:5070/api/RezervasyonAPI", rezervasyon);

                    if (response.IsSuccessStatusCode)
                    {
                        return RedirectToAction(nameof(Index)); //ba�ar�l� ise listeleme sayfas�na y�nlendirir...
                    }
                    else
                    {
                        var content = await response.Content.ReadAsStringAsync();
                        ModelState.AddModelError("", $"Hata: {content}"); //hatal� ise apiden gelen hata mesaj� d�ner...
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", $"Bir hata olu�tu: {ex.Message}");
                }
            }

            // Form tekrar g�ster
            try
            {//hata durumund veay model do�rulama ba�ar�s�z ise dropdown liste verileri tekrar y�klenir...
                var sahaClient = _factory.CreateClient();
                sahaClient.BaseAddress = new Uri("http://localhost:5070/api/SahaAPI/");
                var sahalar = await sahaClient.GetFromJsonAsync<List<Saha>>(sahaClient.BaseAddress);

                var musteriClient = _factory.CreateClient();
                var musteriler = await musteriClient.GetFromJsonAsync<List<Musteri>>("http://localhost:5070/api/MusteriApi");

                ViewBag.MusteriId = new SelectList(musteriler, "Id", "AdSoyad", rezervasyon.MusteriId);
                ViewBag.SahaId = new SelectList(sahalar, "Id", "Ad", rezervasyon.SahaId);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", $"Veriler y�klenirken hata: {ex.Message}");
            }

            return View(rezervasyon); //Form verileri korunur, kullan�c� hatalar� g�rebilir ve d�zeltme yapabilir...

        }










    }
}
