﻿using HaliSaha.Areas.Identity.Data;
using HaliSaha.Models;

using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;


namespace HaliSaha.Areas.Identity.Data;



//burası veritabanı bağlantısını yöneten identity kullanıcılarını ve diğer tabloları yöneten bir EF core dbcontext sınıfını oluşturur.



public class HaliSahaContext : IdentityDbContext<HaliSahaUser>   //ıdentitydbcontexten miras alıyor.
{

    public class HaliSahaUser : IdentityUser  //IdentityUser kullanılarak kullanıcı modeli oluşturuluyor.
    {
    }
    //burda projedeki tablolar dbset olarak tanımlandı.
    public DbSet<Musteri> Musteriler { get; set; }

    public DbSet<Saha> Sahalar { get; set; }
    public DbSet<Rezervasyon> Rezervasyonlar { get; set; }

    //contextin constructoru oluşturuldu.
    public HaliSahaContext(DbContextOptions<HaliSahaContext> options)
        : base(options)
    {
    }
     
    //identtynin varsayılan tabloları buraya kaydedilir.
    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);
        // Customize the ASP.NET Identity model and override the defaults if needed.
        // For example, you can rename the ASP.NET Identity table names and more.
        // Add your customizations after calling base.OnModelCreating(builder);
    }
}
