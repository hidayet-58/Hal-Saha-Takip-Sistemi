
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using HaliSaha.Areas.Identity.Data;
using Microsoft.AspNetCore.Identity;

namespace HaliSaha
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);



            //veritabanı bağlantısı
            builder.Services.AddDbContext<HaliSahaContext>(options =>
            options.UseSqlServer(builder.Configuration.GetConnectionString("HaliSahaAPIContext") ?? throw new IndexOutOfRangeException("Connection string 'HaliSahaAPIContext' not found.")));

            builder.Services.AddDefaultIdentity<HaliSahaUser>(options => options.SignIn.RequireConfirmedAccount = false).AddEntityFrameworkStores<HaliSahaContext>();



            // controller
            builder.Services.AddControllersWithViews(); //mvc yapısı için

            builder.Services.AddHttpClient(); //http istekleri için

            //burda kullanıcı kayıt olduktan sonra direk login olmasını sağladık
            builder.Services.Configure<IdentityOptions>(options =>
            {
                options.SignIn.RequireConfirmedAccount = false;
            });




            var app = builder.Build(); // Uygulamayı oluştur


            if (!app.Environment.IsDevelopment())  // Geliştirme ortamında Swagger'ı etkinleştir
            {
                app.UseExceptionHandler("/Home/Error"); // Hata sayfası yönlendirmesi

                app.UseHsts(); 
            }

            app.UseHttpsRedirection();  // HTTPS yönlendirmesini etkinleştir
            app.UseStaticFiles();       // Statik dosyaları etkinleştir

            app.UseRouting();        // Yönlendirmeyi etkinleştir



            app.UseAuthentication();  // Kimlik doğrulamayı etkinleştir


            app.UseAuthorization();  // Yetkilendirmeyi etkinleştir

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");  // Varsayılan rota yapılandırması
            app.MapRazorPages(); // Razor Pages'i eşleştir
            app.Run(); // Uygulamayı çalıştır


        }
    }
}
