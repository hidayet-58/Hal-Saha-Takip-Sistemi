﻿using System.ComponentModel.DataAnnotations;




namespace HaliSaha.Models
{
    public class Saha
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Ad { get; set; }

        [Required]
        public int Kapasite { get; set; }

        [Required]
        public decimal SaatlikUcret { get; set; }
    }
}
