﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System;

namespace HaliSaha.Models
{
    public class Rezervasyon
    {
       [Key]
        public int Id { get; set; }

        [Required]
        public int MusteriId { get; set; }

        [ForeignKey("MusteriId")]
        public Musteri? Musteri { get; set; }

        [Required]
        public int SahaId { get; set; }

        [ForeignKey("SahaId")]
        public Saha? Saha { get; set; }

        [Required]
        public DateTime BaslangicSaati { get; set; }

        [Required]
        public DateTime BitisSaati { get; set; }

        [Required]
        public decimal ToplamUcret { get; set; }
    }
}
