﻿using HaliSahaAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace HaliSahaAPI.Data
{
    public class HaliSahaAPIContext : DbContext
    {

        public HaliSahaAPIContext(DbContextOptions<HaliSahaAPIContext> options) //constructor...
        : base(options)
        { }
        
        public DbSet<MusteriAPI_> Musteri { get; set; } = default!; //müşteri tablosu
        public DbSet<SahaAPI> Sahalar { get; set; }                 //saha tablosu
        public DbSet<RezervasyonAPI> Rezervasyonlar { get; set; }   //rezervasyon tablosu
    }
}