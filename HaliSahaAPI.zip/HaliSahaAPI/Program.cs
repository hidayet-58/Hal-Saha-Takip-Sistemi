
using HaliSahaAPI.Data;
using Microsoft.EntityFrameworkCore;

namespace HaliSahaAPI
{
    public class Program
    {
        public static void Main(string[] args) //
        {
            var builder = WebApplication.CreateBuilder(args); // Uygulama oluşturucu

            builder.Services.AddDbContext<HaliSahaAPIContext>(options =>
            options.UseSqlServer(builder.Configuration.GetConnectionString("HaliSahaAPIContext") ?? throw new InvalidOperationException("Connection string 'HaliSahaAPIContext' not found."))); // Veritabanı bağlama...

            
            builder.Services.AddCors(options =>// CORS politikası ekle
            {   // Tüm kaynaklara, yöntemlere ve başlıklara izin ver...
                options.AddPolicy("AllowAll", builder =>
                {
                    builder.AllowAnyOrigin() //tüm kaynaklara izin ver
                           .AllowAnyMethod() //tüm yöntemlere izin ver
                           .AllowAnyHeader(); //tüm başlıklara izin ver
                });
            });

            
             
            builder.Services.AddControllers(); // Denetleyicileri ekle

            // Swagger/OpenAPI desteği ekle
            builder.Services.AddEndpointsApiExplorer(); // API uç noktalarını keşfet
            builder.Services.AddSwaggerGen(); // Swagger jeneratörünü ekle

            var app = builder.Build(); // Uygulamayı oluştur

            // CORS middleware'i kullan
            app.UseCors("AllowAll"); 



            if (app.Environment.IsDevelopment()) // Geliştirme ortamında Swagger'ı etkinleştir
            {
                app.UseSwagger();  // Swagger ara yüzü
                app.UseSwaggerUI(); // Swagger kullanıcı arayüzü
            }

            app.UseHttpsRedirection(); // HTTPS yönlendirmesini etkinleştir

            app.UseAuthorization();    // Yetkilendirmeyi etkinleştir

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}"); // Varsayılan rota yapılandırması

            app.MapControllers(); // Denetleyicileri eşleştir

            app.Run();  // Uygulamayı çalıştır
        }
    }
}
