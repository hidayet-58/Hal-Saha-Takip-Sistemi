﻿using HaliSahaAPI.Data;
using HaliSahaAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Threading.Tasks;
using HaliSaha.Models;


namespace HaliSahaAPI.Controllers
{


    [Route("api/[controller]")]
    [ApiController]         //Model binding, validation ve otomatik HTTP 400 gibi özellikleri etkinleştirir...
    public class MusteriApiController : ControllerBase
    {//api veritabanına erişmek için halisahaapicontext i kullanır.
        private readonly HaliSahaAPIContext _context;

        public MusteriApiController(HaliSahaAPIContext context)
        {
            _context = context;
        }

        [HttpGet] //listeleme işlemi için get isteği...
        public async Task<ActionResult<List<MusteriAPI_>>> GetMusteriler() //tüm müşteriler gelir async olarak db den liste ceker..
        {
            return await _context.Musteri.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<MusteriAPI_>> GetMusteri(int id) //id den dolayı tek müşteri çekilir...
        {
            var musteri = await _context.Musteri.FindAsync(id);
            if (musteri == null) return NotFound(); //musteri yoksa 40 döne r...
            return musteri;
        }

        [HttpPost]  ///yeni müşteri ekleme işlemi için post isteği...
        public async Task<ActionResult<MusteriAPI_>> PostMusteri(MusteriAPI_ musteri) 
        {
            _context.Musteri.Add(musteri);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetMusteri), new { id = musteri.Id }, musteri); //eklenen kaydın url sini ve verisini döner...
        }

        [HttpPut("{id}")] //güncelleme...
        public async Task<IActionResult> PutMusteri(int id, MusteriAPI_ musteri)
        {
            if (id != musteri.Id) return BadRequest(); //id uyusmazsa 400 döner request...
            _context.Entry(musteri).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return NoContent(); //başarılı ise 204 döner...
        }

        [HttpDelete("{id}")] //belirli id ye göre silme işlemi...
        public async Task<IActionResult> DeleteMusteri(int id)
        {
            var musteri = await _context.Musteri.FindAsync(id);
            if (musteri == null) return NotFound(); //yoksa 404 döner...
            _context.Musteri.Remove(musteri);
            await _context.SaveChangesAsync();
            return NoContent(); //silinirse 204 döner...
        }
    }


}
