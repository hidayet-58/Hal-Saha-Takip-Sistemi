﻿
using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HaliSahaAPI.Data;
using HaliSahaAPI.Models;

namespace HaliSahaAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RezervasyonAPIController : ControllerBase
    {
        private readonly HaliSahaAPIContext _context;
        public RezervasyonAPIController(HaliSahaAPIContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<List<RezervasyonAPI>>> GetRezervasyonlar() //tüm rez ler gelir..
        {//inculde ile musteri ve saha bilgileri de çekilir...(navigation property) //json formatonda api yanıtı veriri..
            return await _context.Rezervasyonlar
                                 .Include(r => r.musteri)
                                 .Include(r => r.Saha)
                                 .ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<RezervasyonAPI>> GetRezervasyon(int id)
        {
            var rezervasyon = await _context.Rezervasyonlar
                                            .Include(r => r.musteri)
                                            .Include(r => r.Saha)
                                            .FirstOrDefaultAsync(r => r.Id == id);
            if (rezervasyon == null) return NotFound();
            return rezervasyon;
        }

        [HttpPost] //yeni rez ekleme...
        public async Task<IActionResult> PostRezervasyon(RezervasyonAPI rezervasyon)
        {
            // Basit validation: Bitiş > Başlangıç 
            if (rezervasyon.BitisSaati <= rezervasyon.BaslangicSaati)
                return BadRequest("Bitiş saati, başlangıç saatinden küçük olamaz.");

            // Saha fiyatını al ve toplam ücreti hesapla
            var saha = await _context.Sahalar.FindAsync(rezervasyon.SahaId);    //saha bilgisi çekilir...
            if (saha == null) return BadRequest("Seçilen saha bulunamadı."); //saha yoksa 400 döner...

            var saat = (decimal)(rezervasyon.BitisSaati - rezervasyon.BaslangicSaati).TotalHours;//süre hesaplanır...
            rezervasyon.ToplamUcret = saat * saha.SaatlikUcret;//saatlik ücret ile çarpılır...

            _context.Rezervasyonlar.Add(rezervasyon);//yeni rez eklenir...
            await _context.SaveChangesAsync(); //değişiklikler kaydedilir...

            return CreatedAtAction(nameof(GetRezervasyon), new { id = rezervasyon.Id }, rezervasyon);//201 created döner...
        }

        [HttpPut("{id}")] //güncelleme...
        public async Task<IActionResult> PutRezervasyon(int id, RezervasyonAPI rezervasyon) //id ve rezervasyon nesnesi gelir...
        {
            if (id != rezervasyon.Id) return BadRequest(); //id uyuşmazsa 400 döner...BadRequest

            // Validation: Bitiş > Başlangıç
            if (rezervasyon.BitisSaati <= rezervasyon.BaslangicSaati)//bitiş saati başlangıç saatinden küçük olamaz...
                return BadRequest("Bitiş saati, başlangıç saatinden küçük olamaz."); //400 döner...BadRequest

            // Saha fiyatını al ve toplam ücreti hesapla
            var saha = await _context.Sahalar.FindAsync(rezervasyon.SahaId); //saha bilgisi çekilir...
            if (saha == null) return BadRequest("Seçilen saha bulunamadı."); //saha yoksa 400 döner...BadRequest

            var saat = (decimal)(rezervasyon.BitisSaati - rezervasyon.BaslangicSaati).TotalHours; //süre hesaplanır...
            rezervasyon.ToplamUcret = saat * saha.SaatlikUcret; //süre saatlik ücret ile çarpılır...

            _context.Entry(rezervasyon).State = EntityState.Modified; //güncelleme işlemi yapılır...
            await _context.SaveChangesAsync(); //değişiklikler kaydedilir...
            return NoContent(); //204 no content döner...
        }

        [HttpDelete("{id}")] //silme işlemi...
        public async Task<IActionResult> DeleteRezervasyon(int id) //id gelir...
        {
            var rezervasyon = await _context.Rezervasyonlar.FindAsync(id); //rezervasyon bulunur...
            if (rezervasyon == null) return NotFound(); //yoksa 404 döner...
            _context.Rezervasyonlar.Remove(rezervasyon);    //rezervasyon silinir...
            await _context.SaveChangesAsync();  //değişiklikler kaydedilir...
            return NoContent();     //204 no content döner...
        }
    }
}