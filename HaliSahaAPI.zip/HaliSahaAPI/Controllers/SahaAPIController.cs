﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HaliSahaAPI.Data;
using HaliSahaAPI.Models;

namespace HaliSahaAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SahaAPIController : ControllerBase
    {
        private readonly HaliSahaAPIContext _context;
        public SahaAPIController(HaliSahaAPIContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<List<SahaAPI>>> GetSahalar()
        {
            return await _context.Sahalar.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<SahaAPI>> GetSahaById(int id)
        {
            var saha = await _context.Sahalar.FindAsync(id);
            if (saha == null) return NotFound();
            return saha;
        }

        [HttpPost]
        public async Task<ActionResult<SahaAPI>> PostSaha(SahaAPI saha)
        {
            _context.Sahalar.Add(saha);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetSahaById), new { id = saha.Id }, saha);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutSaha(int id, SahaAPI saha)
        {
            if (id != saha.Id) return BadRequest();
            _context.Entry(saha).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteSaha(int id)
        {
            var saha = await _context.Sahalar.FindAsync(id);
            if (saha == null) return NotFound();
            _context.Sahalar.Remove(saha);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}