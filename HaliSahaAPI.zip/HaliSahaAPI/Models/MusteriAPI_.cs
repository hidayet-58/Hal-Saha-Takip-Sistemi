﻿
using System.ComponentModel.DataAnnotations;

namespace HaliSahaAPI.Models
{
    public class MusteriAPI_
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Ad Soyad zorunludur.")]
        [StringLength(50, ErrorMessage = "Ad Soyad en fazla 50 karakter olmalı.")] 
        public string AdSoyad { get; set; }

        [Required(ErrorMessage = "Telefon zorunludur.")]
        [Phone(ErrorMessage = "Geçerli bir telefon numarası giriniz.")]
        public string Telefon { get; set; }

        [Required(ErrorMessage = "Mail zorunludur.")]
        [EmailAddress(ErrorMessage = "Geçerli bir mail adresi giriniz.")]
        public string Mail { get; set; }
    }
}
