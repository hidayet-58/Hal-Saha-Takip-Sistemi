﻿using System.ComponentModel.DataAnnotations;

namespace HaliSahaAPI.Models
{
    public class SahaAPI
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Ad { get; set; }   // Örn: "Saha 1"

        [Required]
        public int Kapasite { get; set; }  // Kaç kişi alır

        [Required]
        public decimal SaatlikUcret { get; set; }  // Saatlik ücret
    }
}