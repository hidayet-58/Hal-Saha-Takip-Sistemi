﻿using System;
using HaliSahaAPI.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;





namespace HaliSahaAPI.Models
{
    public class RezervasyonAPI
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int MusteriId { get; set; }

        [ForeignKey("MusteriId")]
        public MusteriAPI_? musteri { get; set; }

        [Required]
        public int SahaId { get; set; }

        [ForeignKey("SahaId")]
        public SahaAPI? Saha { get; set; }

        [Required]
        public DateTime BaslangicSaati { get; set; }

        [Required]
        public DateTime BitisSaati { get; set; }

        [Required]
        public decimal ToplamUcret { get; set; }
    }
}
